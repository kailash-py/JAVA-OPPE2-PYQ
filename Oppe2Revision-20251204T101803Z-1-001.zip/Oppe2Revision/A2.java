import java.util.*;

class Employee implements Cloneable {
    String name;
    String[] projects;

    public Employee(String n, String[] proj) {
        name = n;
        projects = proj;
    }

    public void setName(String n) {
        name = n;
    }

    public void setProject(int index, String proj) {
        projects[index] = proj;
    }

    public String getName() {
        return name;
    }

    public String getProject(int indx) {
        return projects[indx];
    }

    public Employee clone() throws CloneNotSupportedException {
        Employee e = (Employee) super.clone();
        e.projects = e.projects.clone();
        return e;
    }
}

public class A2 {
    public static void main(String[] args) throws CloneNotSupportedException {
        Scanner sc = new Scanner(System.in);
        String[] proj = {"PJ1", "PJ2", "PJ3"};
        Employee e1 = new Employee("Surya", proj);
        Employee e2 = e1.clone();
        e2.setName(sc.next());
        e2.setProject(0, sc.next());
        System.out.println(e1.getName() + ": " + e1.getProject(0));
        System.out.println(e2.getName() + ": " + e2.getProject(0));
    }
}
